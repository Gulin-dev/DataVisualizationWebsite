import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import List
from matplotlib import colormaps

os.makedirs("../../images", exist_ok=True)
os.makedirs("../../tables", exist_ok=True)

data_file = 'data/vpn-rf.xlsx'
excel_reader = pd.ExcelFile(data_file, engine='openpyxl')
df1 = excel_reader.parse('Обзор рынка', index_col=None, header=None)
df2 = excel_reader.parse('Опрос компаний', index_col=None, header=None)

def split_df(df):
    odf, ndf = [], []
    df_name, years = '', []
    temp_df, is_df = None, False

    for _, row in df.iterrows():
        if pd.notna(row[0]) and pd.isna(row[1]) and pd.isna(row[2]):
            if is_df:
                if years:
                    temp_df.columns = years
                odf.append(temp_df)
                ndf.append(df_name)
            df_name = row[0]
            temp_df, years = pd.DataFrame(), []
            is_df = True
            continue

        if row.isna().all():
            continue

        if is_df and pd.isna(row[0]) and pd.notna(row[1]):
            row[0] = 0
            years = row.dropna().astype(int).tolist()
            continue

        if is_df:
            temp_df = pd.concat([temp_df, pd.DataFrame([row.values])], ignore_index=True)

    if is_df:
        if years:
            temp_df.columns = years
        odf.append(temp_df)
        ndf.append(df_name)

    return odf, ndf

def make_pie(df, filename):
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_subplot()

    color_map = colormaps.get_cmap("viridis")
    colors = [color_map(i / len(df[1])) for i in range(len(df[1]))]

    ax.pie(
        x=np.array(df[1]),
        labels=np.array(df[0]),
        startangle=90,
        autopct='%1.2f%%',
        pctdistance=0.80,
        wedgeprops={'width': 0.40, 'edgecolor': 'w', 'linewidth': 3},
        textprops={'fontsize': 8},
        colors=colors
    )
    plt.savefig(filename, dpi=400)
    plt.close()

def make_bar_chart(df, filename):
    x_labels = df.columns[1:]
    y_values = [df.iloc[i][1:].tolist() for i in range(len(df))]
    names = df.iloc[:, 0].tolist()

    num_categories = len(names)
    width = 0.8 / num_categories
    x = np.arange(len(x_labels))

    fig, ax = plt.subplots(figsize=(10, 5))

    color_map = colormaps.get_cmap("plasma")

    for i in range(num_categories):
        color = color_map(i / num_categories)
        ax.bar(x + i * width, y_values[i], width, label=names[i], color=color)

    ax.set_xticks(x + width * (num_categories - 1) / 2)
    ax.set_xticklabels(x_labels)
    ax.legend()
    plt.savefig(filename, dpi=200)
    plt.close()

odf1, ndf1 = split_df(df1)
odf2, ndf2 = split_df(df2)

make_bar_chart(odf1[0], 'static/images/bar_chart_1.png')
make_bar_chart(odf1[1], 'static/images/bar_chart_2.png')
make_bar_chart(odf1[2], 'static/images/bar_chart_3.png')

make_pie(odf2[0], 'static/images/pie_chart_1.png')
make_pie(odf2[1], 'static/images/pie_chart_2.png')
make_pie(odf2[2], 'static/images/pie_chart_3.png')

def save_styled_tables_to_html(odf: List[pd.DataFrame], ndf: List[str], filename_prefix: str, lang='en'):
    table_style = """
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }
        th, td {
            border: 1px solid #4a4a4a;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #333366;
            color: #ffffff;
        }
        tr:nth-child(even) {
            background-color: #e0d8f7;
        }
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tr:hover {
            background-color: #ffd27f;
        }
    </style>
    """

    for i in range(len(odf)):
        filename = f"static/tables/{filename_prefix}_{i + 1}.html"

        with open(filename, "w", encoding="utf-8") as file:
            file.write(f"<!DOCTYPE html><html lang='{lang}'>")
            file.write("<head><meta charset='UTF-8'></head>")
            file.write("<body>")
            file.write(table_style)
            file.write(odf[i].to_html(index=False, escape=False))
            file.write("</body></html>")

save_styled_tables_to_html(odf1, ndf1, "market")
save_styled_tables_to_html(odf2, ndf2, "survey")

html_content = """
<html>
<head>
    <meta charset="UTF-8">
    <html lang='en'>
    <title>Таблицы и диаграммы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(160deg, #cfe2f3, #f7e6d2);
            color: #333;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            position: relative;
        }

        h1 {
            font-size: 2.2em;
            color: #113c70;
            background: #f8e4c5;
            padding: 15px;
            border-radius: 8px;
            font-weight: bold;
            font-style: italic;
            text-align: center;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        }

        .section {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 10px;
            align-items: flex-start;
            margin-bottom: 50px;
        }

        .title-container {
            text-align: center;
        }

        img {
            max-width: 100%;
            border: 1px solid #ccc;
            padding: 5px;
            background-color: #f9f9f9;
        }

        iframe {
            width: 100%;
            height: 300px;
            border: 1px solid #ccc;
        }

        .wave-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .wave {
            position: absolute;
            width: 100%;
            height: 300px;
            background: none;
            opacity: 0.4;
        }

        .wave sine {
            animation: sine-wave 8s linear infinite;
            height: 100%;
            width: 100%;
            stroke: #113c70;
            fill: transparent;
            stroke-width: 2px;
        }

        .wave cosine {
            animation: cosine-wave 10s linear infinite;
            height: 100%;
            width: 100%;
            stroke: #bf8040;
            fill: transparent;
            stroke-width: 2px;
        }

        @keyframes sine-wave {
            0% {
                transform: translateX(0) translateY(50px);
            }
            100% {
                transform: translateX(-100%) translateY(50px);
            }
        }

        @keyframes cosine-wave {
            0% {
                transform: translateX(0) translateY(150px);
            }
            100% {
                transform: translateX(-100%) translateY(150px);
            }
        }

    </style>
</head>
<body>
<h1>Обзор рынка</h1>

<div class="wave-container">
    <svg class="wave sine" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path d="M0,256L48,234.7C96,213,192,171,288,138.7C384,107,480,85,576,69.3C672,53,768,43,864,53.3C960,64,1056,96,1152,96C1248,96,1344,64,1392,48L1440,32L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path></svg>
    <svg class="wave cosine" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path d="M0,320L48,288C96,256,192,192,288,160C384,128,480,128,576,160C672,192,768,256,864,277.3C960,299,1056,277,1152,234.7C1248,192,1344,128,1392,96L1440,64L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path></svg>
</div>
"""

for i in range(len(ndf1)):
    html_content += f"""
    <div class="section">
        <div class="title-container">
            <h2>{ndf1[i]}</h2>
        </div>
        <div>
            <img src='../static/images/bar_chart_{i + 1}.png' alt='{ndf1[i]}'>
        </div>
        <div>
            <iframe src='../static/tables/market_{i + 1}.html'></iframe>
        </div>
    </div>
    """

html_content += "<h1>Опрос компаний</h1>"

for i in range(len(ndf2)):
    html_content += f"""
    <div class="section">
        <div class="title-container">
            <h2>{ndf2[i]}</h2>
        </div>
        <div>
            <img src='../static/images/pie_chart_{i + 1}.png' alt='{ndf2[i]}'>
        </div>
        <div>
            <iframe src='../static/tables/survey_{i + 1}.html'></iframe>
        </div>
    </div>
    """

html_content += "</body></html>"

with open('templates/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)