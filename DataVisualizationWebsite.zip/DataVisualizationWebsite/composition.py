import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import List
from matplotlib import colormaps

os.makedirs("static/images", exist_ok=True)
os.makedirs("static/tables", exist_ok=True)

data_file = 'data/vpn-rf.xlsx'
excel_reader = pd.ExcelFile(data_file, engine='openpyxl')
df1 = excel_reader.parse('Обзор рынка', index_col=None, header=None)
df2 = excel_reader.parse('Опрос компаний', index_col=None, header=None)

def split_df(df):
    odf, ndf = [], []
    df_name, years = '', []
    temp_df, is_df = None, False

    for _, row in df.iterrows():
        if pd.notna(row[0]) and pd.isna(row[1]) and pd.isna(row[2]):
            if is_df:
                if years:
                    temp_df.columns = years
                odf.append(temp_df)
                ndf.append(df_name)
            df_name = row[0]
            temp_df, years = pd.DataFrame(), []
            is_df = True
            continue

        if row.isna().all():
            continue

        if is_df and pd.isna(row[0]) and pd.notna(row[1]):
            row[0] = 0
            years = row.dropna().astype(int).tolist()
            continue

        if is_df:
            temp_df = pd.concat([temp_df, pd.DataFrame([row.values])], ignore_index=True)

    if is_df:
        if years:
            temp_df.columns = years
        odf.append(temp_df)
        ndf.append(df_name)

    return odf, ndf

def make_pie(df, filename):
    fig, ax = plt.subplots(figsize=(6, 6))
    color_map = colormaps.get_cmap("viridis")
    colors = [color_map(i / len(df[1])) for i in range(len(df[1]))]

    ax.pie(
        x=np.array(df[1]),
        labels=np.array(df[0]),
        startangle=90,
        autopct='%1.2f%%',
        pctdistance=0.80,
        wedgeprops={'width': 0.40, 'edgecolor': 'w', 'linewidth': 3},
        textprops={'fontsize': 8},
        colors=colors
    )
    plt.savefig(filename, format='svg', dpi=400)
    plt.close()

def make_bar_chart(df, filename):
    x_labels = df.columns[1:]
    y_values = [df.iloc[i][1:].tolist() for i in range(len(df))]
    names = df.iloc[:, 0].tolist()

    num_categories = len(names)
    width = 0.8 / num_categories
    x = np.arange(len(x_labels))

    fig, ax = plt.subplots(figsize=(10, 5))
    color_map = colormaps.get_cmap("plasma")

    for i in range(num_categories):
        color = color_map(i / num_categories)
        ax.bar(x + i * width, y_values[i], width, label=names[i], color=color)

    ax.set_xticks(x + width * (num_categories - 1) / 2)
    ax.set_xticklabels(x_labels)
    ax.legend()
    plt.savefig(filename, format='svg', dpi=200)
    plt.close()

odf1, ndf1 = split_df(df1)
odf2, ndf2 = split_df(df2)

for i in range(len(odf1)):
    make_bar_chart(odf1[i], f'static/images/bar_chart_{i + 1}.svg')

for i in range(len(odf2)):
    make_pie(odf2[i], f'static/images/pie_chart_{i + 1}.svg')


def save_styled_tables_to_html(odf: List[pd.DataFrame], ndf: List[str], filename_prefix: str, lang='en'):
    table_style = """
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            border: 1px solid #4a4a4a;
            padding: 12px;
            text-align: left;
            border-radius: 5px;
            box-sizing: border-box;
            transition: transform 0.2s ease, background-color 0.3s ease;
        }
        th {
            background-color: #333366;
            color: #ffffff;
        }
        td {
            background-color: #ffcccc;  /* Default rainbow color for cells */
        }
        /* Rainbow gradient for cells */
        td:nth-child(1) { background-color: #ff6666; }  /* Red */
        td:nth-child(2) { background-color: #ff9900; }  /* Orange */
        td:nth-child(3) { background-color: #ffff66; }  /* Yellow */
        td:nth-child(4) { background-color: #66ff66; }  /* Green */
        td:nth-child(5) { background-color: #66ccff; }  /* Blue */
        td:nth-child(6) { background-color: #cc66ff; }  /* Violet */
        /* Hover effects for each cell */
        td:hover {
            transform: scale(1.2);
            background-color: #ffd27f;
        }
        tr:hover {
            background-color: #ffd27f;
        }
        tr:nth-child(even) td {
            background-color: #f3e5f5;
        }
        tr:nth-child(odd) td {
            background-color: #fce4ec;
        }
    </style>
    """

    for i in range(len(odf)):
        filename = f"static/tables/{filename_prefix}_{i + 1}.html"
        with open(filename, "w", encoding="utf-8") as file:
            file.write(f"<!DOCTYPE html><html lang='{lang}'>")
            file.write("<head><meta charset='UTF-8'></head>")
            file.write("<body>")
            file.write(table_style)
            file.write(odf[i].to_html(index=False, escape=False))
            file.write("</body></html>")


save_styled_tables_to_html(odf1, ndf1, "market")
save_styled_tables_to_html(odf2, ndf2, "survey")

html_content = """
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Таблицы и диаграммы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(100deg, #2c409a, #1a7068, #8a00ff);
            color: #fff;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
    
        h1 {
            font-size: 2.5em;
            color: #c800ff;
            background: rgba(142, 0, 255, 0.47);
            padding: 20px;
            border-radius: 8px;
            font-weight: bold;
            font-style: italic;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
            margin-bottom: 30px;
        }
    
        h2 {
            font-size: 1.7em;
            color: #ffffff;
            text-align: center;
            margin-top: 30px;
            text-transform: uppercase;
        }
    
        .section {
            margin-bottom: 60px;
            padding: 10px;
        }
    
        img {
            max-width: 100%;
            border: 3px solid #f8e4c5;
            padding: 10px;
            border-radius: 10px;
            background-color: #f9f9f9;
            transition: transform 0.3s ease;
        }
    
        img:hover {
            transform: scale(1.05);
        }
    
        iframe {
            width: 100%;
            height: 400px;
            border: 1px solid #ccc;
            margin-top: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
    
        /* Для таблиц */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
    
        table th, table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #00ff00, #00b8ff, #8a00ff);
            background-size: 400% 400%;
            animation: gradientAnimation 5s ease infinite;
            color: #fff;
            font-size: 1.2em;
        }
    
        table th {
            background-color: #ff5733;
            font-weight: bold;
        }
    
        table td {
            background-color: rgba(255, 255, 255, 0.2);
        }
    
        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }
    
        @media (max-width: 768px) {
            h1 {
                font-size: 1.8em;
            }
    
            h2 {
                font-size: 1.3em;
            }
    
            iframe {
                height: 300px;
            }
    
            table th, table td {
                padding: 12px;
                font-size: 1em;
            }
        }
    </style>

</head>
<body>
    <div class="container">
        <h1>Обзор рынка</h1>
"""

for i in range(len(ndf1)):
    html_content += f"""
        <div class="section">
            <h2>{ndf1[i]}</h2>
            <div class="row">
                <div class="col-12 col-md-6">
                    <img src='../static/images/bar_chart_{i + 1}.svg' alt='{ndf1[i]}'>
                </div>
                <div class="col-12 col-md-6">
                    <iframe src='../static/tables/market_{i + 1}.html'></iframe>
                </div>
            </div>
        </div>
    """

html_content += "<h1>Опрос компаний</h1>"

for i in range(len(ndf2)):
    html_content += f"""
        <div class="section">
            <h2>{ndf2[i]}</h2>
            <div class="row">
                <div class="col-12 col-md-6">
                    <img src='../static/images/pie_chart_{i + 1}.svg' alt='{ndf2[i]}'>
                </div>
                <div class="col-12 col-md-6">
                    <iframe src='../static/tables/survey_{i + 1}.html'></iframe>
                </div>
            </div>
        </div>
    """

html_content += """
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

with open('templates/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)